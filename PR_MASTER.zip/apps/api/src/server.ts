import { createGraphStore } from '@rdi/graph';
import { createGitHubClient } from '@rdi/providers';
import { createAnthropicLlm } from './agent/anthropicLlm';
import { createFakeLlm } from './agent/fakeLlm';
import { createAnthropicScopeGuard, createFakeScopeGuard } from './agent/scopeGuard';
import { buildApp } from './app';
import { createInfraChecks, createPgPool, createRedisClient } from './checks';
import { loadConfig } from './config';
import { ensureDatabase } from './db/ensureDatabase';
import { runMigrations } from './db/migrate';
import { createMailer } from './mail/mailer';
import { createIndexQueue } from './queue/indexQueue';

const APP_POOL_SIZE = 10;

const config = loadConfig();
if (config.dbEnsure) await ensureDatabase(config.databaseUrl);
const pool = createPgPool(config.databaseUrl, APP_POOL_SIZE);
const applied = await runMigrations(pool);
if (applied.length > 0) console.log(`applied migrations: ${applied.join(', ')}`);
const redis = createRedisClient(config.redisUrl);
const mailer = createMailer(config);
const graph = createGraphStore(config.neo4jUrl, config.neo4jUser, config.neo4jPassword);
await graph.ensureSchema();
const indexQueue = createIndexQueue(config.redisUrl);
const llm = config.agent.fake ? createFakeLlm() : config.agent.enabled ? createAnthropicLlm(config.agent.model) : null;
const scopeGuard = config.agent.fake ? createFakeScopeGuard() : config.agent.enabled ? createAnthropicScopeGuard() : undefined;
const github = config.github ? createGitHubClient({ appId: config.github.appId, privateKey: config.github.privateKey, slug: config.github.slug }) : null;
const infra = createInfraChecks(config);

const app = buildApp({
  checks: infra.checks,
  onClose: async () => {
    await infra.close();
    await pool.end();
    redis.disconnect();
    await indexQueue.close();
    await graph.close();
  },
  deps: { config, pool, redis, mailer, graph, indexQueue, github, llm, scopeGuard },
});

await app.listen({ port: config.port, host: '0.0.0.0' });
console.log(`api listening on http://localhost:${config.port}${config.devRoutes ? ' (dev routes on)' : ''}`);
console.log(`agent: ${llm ? llm.model : 'disabled (set ANTHROPIC_API_KEY or AGENT_ENABLED=true)'}`);
